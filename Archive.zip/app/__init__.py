"""Smart Grid Renewable Energy Forecasting Package."""
__version__ = "1.0.0"
